# Sparewall: Determination — Android projesi

Oyun (HTML5) bir WebView içinde çalışır; simge, paylaştığın görselden üretildi.
Ekranda dokunmatik düğmeler (yön tuşları, Z, X, M, C) otomatik çıkar. Oyun yatay modda açılır.

## APK nasıl alınır (3 yol)

### 1) GitHub ile (bilgisayara bir şey kurmadan, önerilen)
1. github.com'da yeni bir depo aç ve bu klasörün içeriğini yükle (.github klasörü dahil).
2. Depoda **Actions → "APK Derle" → Run workflow** de.
3. İş bitince sayfanın altındaki **Artifacts → Sparewall-Determination-apk** dosyasını indir, zip'ten APK çıkar.
4. APK'yı telefona at, aç ve "bilinmeyen kaynaklardan yüklemeye izin ver" de.

### 2) Android Studio ile
Klasörü **Open** ile aç → Gradle senkronu bitince **Build → Build APK(s)**.
Çıktı: `app/build/outputs/apk/debug/app-debug.apk`

### 3) Komut satırı
Android SDK + JDK 17 kuruluyken: `gradle assembleDebug`

## Notlar
- APK debug anahtarıyla imzalıdır, telefona kurulabilir. Play Store için kendi anahtarınla imzalaman gerekir.
- Oyun dosyaları: `app/src/main/assets/` (index.html ve assets/*.jpg). Tarayıcıda index.html'i açarak da oynanır.
- Yazı tipleri internetten gelir; çevrimdışıyken yedek yazı tipi kullanılır.
